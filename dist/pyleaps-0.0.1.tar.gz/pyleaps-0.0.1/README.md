This is a simple porting of regsubsets in R from the leaps package. 
It is still far from being optimized, but we will eventually get there.
In addition, for now, the user needs to manually code the categorical variable contrasts. This will be fixed in the future.
